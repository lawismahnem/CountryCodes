const express = require('express');
const session = require('express-session')
const app = express();

app.listen(3000);

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.get('/', (req, res) => {
    res.render('index', { title: 'index' });
  });

app.post('/login',(req,res) => {
    console.log(req.sessionID);
    const { username, password } = req.body;
    if(username && password){
        if(req.session.authenticated){
            res.json(req.session);
        }else{
            if(password === '123'){
                req.session.authenticated = true;
                req.session.user ={
                    username, password
                };
                req.json(req,session);
            }else{
                req.status(403).json({msg: 'bad credentials'});
            }
        }
    }else res.status(403).json({msg: 'bad credentials'});
    res.send(200);
})

app.use((req, res) => {
  res.status(404).render('index', { title: '404' });
});